"""
theme.py
Loads the custom frontend/ CSS + JS assets into the Streamlit app, and
provides small helpers for building the themed HTML components used in
streamlit_app.py (hero header, scan-frame images, signal meters).

Keeping this logic here (rather than inline in streamlit_app.py) keeps
the page script focused on pipeline logic, not markup construction.
"""

import base64
import io
import os

import streamlit as st
import streamlit.components.v1 as components
from PIL import Image

from python.utils.config_loader import resolve_path


def inject_theme():
    """Loads frontend/css/theme.css into the page via a <style> block,
    and mounts the ambient particle canvas + its JS behind all content."""
    css_path = resolve_path("frontend/css/theme.css")
    with open(css_path, "r", encoding="utf-8") as f:
        css = f.read()
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)

    js_path = resolve_path("frontend/js/particles.js")
    with open(js_path, "r", encoding="utf-8") as f:
        js = f.read()

    # Fixed full-screen canvas sits behind Streamlit's content (z-index -1)
    # and is populated by particles.js.
    components.html(
        f"""
        <canvas id="mv-particle-canvas"
            style="position:fixed; top:0; left:0; width:100vw; height:100vh;
                   z-index:-1; pointer-events:none;"></canvas>
        <script>{js}</script>
        """,
        height=0,
        width=0,
    )


def render_header(title: str, subtitle: str, status_label: str = "SYSTEM ONLINE"):
    """Renders the glass-panel hero header with logo, title, and a live
    status pill (mirrors the reference dashboard's top bar)."""
    st.markdown(
        f"""
        <div class="mv-header">
            <div class="mv-logo-icon">🫁</div>
            <div>
                <p class="mv-title">{title}</p>
                <p class="mv-subtitle">{subtitle}</p>
            </div>
            <div class="mv-status-pill">
                <span class="mv-status-dot"></span>{status_label}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_pipeline_chips(steps: list):
    """Renders the pipeline steps as glowing chips instead of a plain
    numbered markdown list."""
    chips_html = "".join(
        f"""<div class="mv-pipeline-chip">
                <span class="mv-pipeline-num">{i+1:02d}</span>{step}
            </div>"""
        for i, step in enumerate(steps)
    )
    st.markdown(f'<div class="mv-pipeline">{chips_html}</div>', unsafe_allow_html=True)


def _image_to_base64(image) -> str:
    """Accepts a PIL Image or numpy array and returns a base64 PNG data URI."""
    if not isinstance(image, Image.Image):
        image = Image.fromarray(image)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode()
    return f"data:image/png;base64,{encoded}"


def render_scan_frame(image, label: str):
    """Wraps an image in the signature HUD scan-frame: glowing corner
    brackets, an animated sweep line, and a monospace caption label."""
    data_uri = _image_to_base64(image)
    st.markdown(
        f"""
        <div class="mv-scan-frame">
            <div class="mv-corner tl"></div>
            <div class="mv-corner tr"></div>
            <div class="mv-corner bl"></div>
            <div class="mv-corner br"></div>
            <div class="mv-scanline"></div>
            <img src="{data_uri}" />
            <div class="mv-frame-label">{label}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_signal_meters(findings: dict, threshold: float):
    """Renders classifier findings as glowing horizontal signal-meter
    bars (amber = flagged above threshold, dim cyan = below threshold),
    with monospace percentage readouts -- replaces the plain bar chart."""
    rows_html = []
    for name, prob in findings.items():
        flagged = prob >= threshold
        state = "flagged" if flagged else "clear"
        pct = prob * 100
        rows_html.append(
            f"""
            <div class="mv-meter-row">
                <div class="mv-meter-label">{name}</div>
                <div class="mv-meter-track">
                    <div class="mv-meter-fill {state}" style="width:{pct:.1f}%;"></div>
                </div>
                <div class="mv-meter-value {state}">{pct:5.1f}%</div>
            </div>
            """
        )
    st.markdown("".join(rows_html), unsafe_allow_html=True)


def render_eyebrow(text: str):
    """Small monospace uppercase label used above section headings."""
    st.markdown(f'<div class="mv-eyebrow">{text}</div>', unsafe_allow_html=True)


def report_card_open():
    st.markdown('<div class="mv-report-card">', unsafe_allow_html=True)


def report_card_close():
    st.markdown('</div>', unsafe_allow_html=True)
